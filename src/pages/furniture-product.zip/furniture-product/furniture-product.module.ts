import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FurnitureProductPage } from './furniture-product';

@NgModule({
  declarations: [
    FurnitureProductPage,
  ],
  imports: [
    IonicPageModule.forChild(FurnitureProductPage),
  ],
})
export class FurnitureProductPageModule {}
