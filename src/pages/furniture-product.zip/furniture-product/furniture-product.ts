import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ModalController } from 'ionic-angular';
import { FurnitureCatViewPage } from '../furniture-cat-view/furniture-cat-view';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
// import { FurnitureProductDescriptionPage } from '../furniture-product-description/furniture-product-description';
import { FurnitureProductDescriptionPage } from '../furniture-product-description/furniture-product-description';
import firebase from 'firebase';
import { FurnitureAddtocartPage } from '../furniture-addtocart/furniture-addtocart';
// import TypeIt from 'typeit';
/**
 * Generated class for the FurnitureProductPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */


@Component({
  selector: 'page-furniture-product',
  templateUrl: 'furniture-product.html',
})
export class FurnitureProductPage {

  TempProductArrayLeft = [];
  TempProductArrayRight = [];
  public CategoryID = "";
  public CategoryImage = "";
  AllcatArray = [];

  public countryList: Array<any>;
  public loadedCountryList: Array<any>;
  public countryRef: firebase.database.Reference;

  constructor(public navCtrl: NavController, public navParams: NavParams, public modalCtrl: ModalController, private database: AngularFireDatabase) {
    var catId = this.navParams.get('categoryID');
    this.CategoryImage = this.navParams.get('categoryImage');
    this.CategoryID = catId;

    this.ViewCategory();
    alert(this.CategoryID);

    this.countryRef = firebase.database().ref('/Product');
    // if(catId == 1){
    //   this.TemporarayItemArray1()
    // }
    // else if(catId == 2){
    //   this.TemporarayItemArray2()
    // }
    // else if(catId == 3){
    //   this.TemporarayItemArray3()
    // }
    // else if(catId == 4){
    //   this.TemporarayItemArray4()
    // }
    // else if(catId == 5){
    //   this.TemporarayItemArray5()
    // }
    // else if(catId == 6){
    //   this.TemporarayItemArray6()
    // }

    // this.countryRef.on('value', countryList => {
    //   let countries = [];
    //   countryList.forEach( country => {
    //     countries.push(country.val());
    //     return false;
    //   });

    //   this.countryList = countries;
    //   this.loadedCountryList = countries;
    // });
  }
  initializeItems(): void {
    this.countryList = this.loadedCountryList;
  }
  AllCat = [];
  myInput = "";
  presentModal(param, _CatID) {
    this.CategoryID = _CatID
    alert(_CatID)
    const modal = this.modalCtrl.create(FurnitureProductDescriptionPage, { ProductInfo: param, CategoryName: this.CategoryID });
    modal.present();
  }

  ViewCategory() {
    this.database.object('FurnitureDB/Category').valueChanges().subscribe(data => {
      let SubArr = Object.keys(data);
      this.AllcatArray = [];
      for (var loop = 0; loop < SubArr.length; loop++) {
        const object2 = Object.assign({ CatID: SubArr[loop] }, data[SubArr[loop]]);
        if (loop < 2) {
          this.AllcatArray.push(object2);
        } else {
          this.AllCat.push(object2);
        }
       
        // this.AllcatArray.push(object2);
        // this.AllCat.push(object2);
        console.clear();
        console.log(this.AllcatArray[0].Name);

      }
      debugger;
      this.GetAllProduct();

    })
  }
  gotoAddtoCart() {
    this.navCtrl.push(FurnitureAddtocartPage)
  }
  SelectSearch(index) {
    this.myInput = this.countryList[index].ProductName;
  }
  IsReadyToSearch = false;
  onInput(event) {
    // Reset items back to all of the items
    // this.initializeItems();
    this.IsReadyToSearch = true;
    // set q to the value of the searchbar
    var q = event.srcElement.value;


    // if the value is an empty string don't filter the items
    if (!q) {
      this.countryList = this.TempProductArrayLeft
      this.IsReadyToSearch = false;
      return;
    }

    this.TempProductArrayLeft.filter((v) => {

    });

    this.countryList = this.TempProductArrayLeft.filter((v) => {

      if (v.ProductName && q) {

        if (v.ProductName.toLowerCase().indexOf(q.toLowerCase()) > -1) {
          return true;
        }
        return false;
      }
    });

    console.log(q, this.countryList.length);
  }
  onCancelInput(event) {

    console.log(event);
    this.IsReadyToSearch = false;
    this.countryList = this.TempProductArrayLeft;
  }
  FirstRowProduct = [];
  SecondRowProduct = [];
  GetAllProduct() {
    this.database.object('FurnitureDB/Product').valueChanges().subscribe(data => {
      let SubArr = Object.keys(data);
      this.TempProductArrayLeft = [];

      for (var loop = 0; loop < SubArr.length; loop++) {
        // if (this.CategoryID == data[SubArr[loop]].Category) {
        const object2 = Object.assign({ ID: SubArr[loop] }, data[SubArr[loop]]);
        // if (loop % 2 == 0) {
        this.TempProductArrayLeft.push(object2);
        // }
        // else {
        //   this.TempProductArrayRight.push(object2)
        // }
        // }

      }

      this.countryList = this.TempProductArrayLeft;

      if (this.AllcatArray.length > 2) {
        this.AllcatArray.length = 2;
        this.FirstRowProduct = this.TempProductArrayLeft.filter(items => items.Category == this.AllcatArray[0].CategoryName);
        this.SecondRowProduct = this.TempProductArrayLeft.filter(items => items.Category == this.AllcatArray[1].CategoryName);

      }
    })
  }

  // TemporarayItemArray1(){
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "BedOne",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/bed/1.jpg"
  //   })
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "BedTwo",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/bed/2.jpg"
  //   })
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "BedThree",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/bed/3.jpg"
  //   })
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "BedFour",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/bed/4.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "BedFive",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/bed/5.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "BedSix",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/bed/6.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "BedSeven",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/bed/7.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "BedEight",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/bed/8.jpg"
  //   })
  // }

  // TemporarayItemArray2(){
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "ChairOne",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/chair/1.jpg"
  //   })
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "ChairTwo",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/chair/2.jpg"
  //   })
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "ChairThree",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/chair/3.jpg"
  //   })
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "ChairFour",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/chair/4.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "ChairFive",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/chair/5.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "ChairSix",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/chair/6.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "ChairSeven",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/chair/7.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "ChairEight",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/chair/8.jpg"
  //   })
  // }

  // TemporarayItemArray3(){
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "CupboardOne",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/cupboard/1.jpg"
  //   })
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "CupboardTwo",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/cupboard/2.jpg"
  //   })
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "CupboardThree",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/cupboard/3.jpg"
  //   })
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "CupboardFour",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/cupboard/4.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "CupboardFive",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/cupboard/5.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "CupboardSix",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/cupboard/6.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "CupboardSeven",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/cupboard/7.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "CupboardEight",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/cupboard/8.jpg"
  //   })
  // }

  // TemporarayItemArray4(){
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "OfficeOne",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Office/1.jpg"
  //   })
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "OfficeTwo",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Office/2.jpg"
  //   })
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "OfficeThree",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Office/3.jpg"
  //   })
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "OfficeFour",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Office/4.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "OfficeFive",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Office/5.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "OfficeSix",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Office/6.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "OfficeSeven",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Office/7.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "OfficeEight",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Office/8.jpg"
  //   })
  // }

  // TemporarayItemArray5(){
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "SofaOne",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Sofa/1.jpg"
  //   })
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "SofaTwo",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Sofa/2.jpg"
  //   })
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "SofaThree",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Sofa/3.jpg"
  //   })
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "SofaFour",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Sofa/4.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "SofaFive",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Sofa/5.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "SofaSix",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Sofa/6.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "SofaSeven",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Sofa/7.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "SofaEight",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Sofa/8.jpg"
  //   })
  // }

  // TemporarayItemArray6(){
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "TableOne",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Table/1.jpg"
  //   })
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "TableTwo",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Table/2.jpg"
  //   })
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "TableThree",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Table/3.jpg"
  //   })
  //   this.TempProductArrayLeft.push({
  //     category : 1,
  //     productName : "TableFour",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Table/4.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "TableFive",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Table/5.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "TableSix",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Table/6.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "TableSeven",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Table/7.jpg"
  //   })
  //   this.TempProductArrayRight.push({
  //     category : 1,
  //     productName : "TableEight",
  //     productDetail  : "This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail This is prodeuct Detail ",
  //     ProductPrice : 10000,
  //     productImage : "assets/imgs/Table/8.jpg"
  //   })
  // }


  ionViewDidLoad() {
    console.log('ionViewDidLoad FurnitureProductPage');
  }

}
