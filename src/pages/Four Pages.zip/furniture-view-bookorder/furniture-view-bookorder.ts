import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController } from 'ionic-angular';
import { GeneralProvider } from "../../providers/general/general";
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { FurnitureBookOrderDetailPage } from "../furniture-book-order-detail/furniture-book-order-detail";
/**
 * Generated class for the FurnitureViewBookorderPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-furniture-view-bookorder',
  templateUrl: 'furniture-view-bookorder.html',
})
export class FurnitureViewBookorderPage {

  OrderArray = [];
  constructor(public navCtrl: NavController, public navParams: NavParams, private database: AngularFireDatabase, public ObjGeneral: GeneralProvider, public modalCtrl: ModalController) {
    this.GeAllOrders();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad FurnitureViewBookorderPage');
  }

  OrderDeatils(param , Status , OrderID) {
    const modal = this.modalCtrl.create(FurnitureBookOrderDetailPage, { ProductInfo: param , Status : Status , OrderID : OrderID});
    modal.present();
  }

  GeAllOrders(){
     this.database.object('FurnitureDB/Orders').valueChanges().subscribe(data => {
      let SubArr = Object.keys(data);
      this.OrderArray = [];
      for (var loop = 0; loop < SubArr.length; loop++) {
        const object2 = Object.assign({ ID: SubArr[loop] }, data[SubArr[loop]]);
        this.OrderArray.push(object2);
      }
    })
  }

}
