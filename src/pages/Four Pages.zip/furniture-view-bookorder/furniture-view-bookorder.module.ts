import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FurnitureViewBookorderPage } from './furniture-view-bookorder';

@NgModule({
  declarations: [
    FurnitureViewBookorderPage,
  ],
  imports: [
    IonicPageModule.forChild(FurnitureViewBookorderPage),
  ],
})
export class FurnitureViewBookorderPageModule {}
