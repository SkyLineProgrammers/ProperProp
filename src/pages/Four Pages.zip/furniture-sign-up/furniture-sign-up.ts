import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { FurnitureLoginPage } from '../furniture-login/furniture-login';
/**
 * Generated class for the FurnitureSignUpPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-furniture-sign-up',
  templateUrl: 'furniture-sign-up.html',
})
export class FurnitureSignUpPage {

  // Declear local variables
  public UserName = "";
  public Password = "";
  public Email = "";
  public Number = "";
  public gender = "";
  public agreement = false;

  constructor(public navCtrl: NavController, public navParams: NavParams, private database: AngularFireDatabase) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad FurnitureSignUpPage');
  }


  Reset() {
    this.UserName = "";
    this.Password = "";
    this.Email = "";
    this.Number = "";
    this.gender = "";
    this.agreement = false;
  }

  Submit() {
    if (this.UserName != "" && this.Password != "" && this.Email !== "" && this.Number !== "") {
      this.database.list("FurnitureDB/Users/" + this.UserName + " & " + this.Password).push({
        LogInID: this.UserName,
        LogInPassword: this.Password,
        Email: this.Email,
        Number: this.Number,
        Gender: this.gender,
        Agreement: this.agreement

      });

      this.database.list("FurnitureDB/AddtoCart/" + this.UserName + " & " + this.Password).push({
        ProductID : ""       
      });

      this.database.list("FurnitureDB/WishList/" + this.UserName + " & " + this.Password).push({
        ProductID : ""
      });

      this.Reset();
      this.navCtrl.push(FurnitureLoginPage)
    } else {
      alert("Fill field first");
    }
  }

}
