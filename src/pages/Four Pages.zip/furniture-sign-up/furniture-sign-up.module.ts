import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FurnitureSignUpPage } from './furniture-sign-up';

@NgModule({
  declarations: [
    FurnitureSignUpPage,
  ],
  imports: [
    IonicPageModule.forChild(FurnitureSignUpPage),
  ],
})
export class FurnitureSignUpPageModule {}
