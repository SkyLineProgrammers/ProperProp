import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { AngularFireAuth } from 'angularfire2/auth';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { FurnitureSignUpPage } from '../furniture-sign-up/furniture-sign-up';
import { FurnitureCatViewPage } from '../furniture-cat-view/furniture-cat-view';
import { GeneralProvider } from '../../providers/general/general';
import { FurnitureDashboardPage } from '../furniture-dashboard/furniture-dashboard';


@IonicPage()
@Component({
  selector: 'page-furniture-login',
  templateUrl: 'furniture-login.html',
})
export class FurnitureLoginPage {
  
  
  public UserName = "";
  public Password = "";
  public LogerInfo = [];

  constructor(public navCtrl: NavController, public navParams: NavParams, private fire: AngularFireAuth, private database: AngularFireDatabase, private ObjGeneral : GeneralProvider) {

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LogInPage');
  }


  // LogIn() {

  // } a rhi 

  LogIn() {
    let UserPass = this.UserName + " & " + this.Password;

    var Sucess;
    if (this.UserName != "" && this.Password != "") {
      this.database.object('/FurnitureDB/Users/').valueChanges().subscribe(data => {
        let FirstArr = Object.keys(data);   //FirstArr have All username
        for (var i = 0; i < FirstArr.length; i++) {
          if (UserPass == FirstArr[i]) {
            this.database.object('/FurnitureDB/Users/' + UserPass).valueChanges().subscribe(data => {
              let SubArr = Object.keys(data); //SubArr have all data inside signUp
              this.LogerInfo = data[SubArr[0]];
              this.ObjGeneral.setUserInfo(this.LogerInfo);
              this.ObjGeneral.setUserName(UserPass);
              var test = this.ObjGeneral.UserName;
              this.navCtrl.push(FurnitureDashboardPage);
            }) 
          }
        }
      })
    }
  }


  SignUp() {
    this.navCtrl.push(FurnitureSignUpPage);
   }
}