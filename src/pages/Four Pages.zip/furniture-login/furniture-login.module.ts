import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FurnitureLoginPage } from './furniture-login';

@NgModule({
  declarations: [
    FurnitureLoginPage,
  ],
  imports: [
    IonicPageModule.forChild(FurnitureLoginPage),
  ],
})
export class FurnitureLoginPageModule {}
