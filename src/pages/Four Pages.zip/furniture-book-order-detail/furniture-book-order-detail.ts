import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';
import { AngularFireDatabase } from "angularfire2/database";

/**
 * Generated class for the FurnitureBookOrderDetailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-furniture-book-order-detail',
  templateUrl: 'furniture-book-order-detail.html',
})
export class FurnitureBookOrderDetailPage {

  AddToCartInfo;
  status = "";
  OrderID = "";

  constructor(public navCtrl: NavController, public navParams: NavParams, public viewCtrl: ViewController, private database: AngularFireDatabase) {
    this.AddToCartInfo = this.navParams.get('ProductInfo');
    this.status = this.navParams.get('Status');
    this.OrderID = this.navParams.get('OrderID');
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad FurnitureBookOrderDetailPage');
  }

  ConfirmOrder() {
    if (this.status == "0") {
      this.database.list('FurnitureDB/Orders/').update(this.OrderID, {
        isBooked: "1"
      })
      this.dismiss();
    }
    else {
      alert("Already Bo0ked");
    }
  }

  dismiss() {
    this.viewCtrl.dismiss();
  }

}
