import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FurnitureBookOrderDetailPage } from './furniture-book-order-detail';

@NgModule({
  declarations: [
    FurnitureBookOrderDetailPage,
  ],
  imports: [
    IonicPageModule.forChild(FurnitureBookOrderDetailPage),
  ],
})
export class FurnitureBookOrderDetailPageModule {}
