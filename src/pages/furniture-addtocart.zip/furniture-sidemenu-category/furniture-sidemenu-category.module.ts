import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FurnitureSidemenuCategoryPage } from './furniture-sidemenu-category';

@NgModule({
  declarations: [
    FurnitureSidemenuCategoryPage,
  ],
  imports: [
    IonicPageModule.forChild(FurnitureSidemenuCategoryPage),
  ],
})
export class FurnitureSidemenuCategoryPageModule {}
