import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController } from 'ionic-angular';
import { AngularFireDatabase } from "angularfire2/database";
import { FurnitureProductDescriptionPage } from "../furniture-product-description/furniture-product-description";

/**
 * Generated class for the FurnitureSidemenuCategoryPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-furniture-sidemenu-category',
  templateUrl: 'furniture-sidemenu-category.html',
})
export class FurnitureSidemenuCategoryPage {
  TempProductArrayLeft: any[];
  CategoryID: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public modalCtrl: ModalController, private database: AngularFireDatabase) {
    var catId = this.navParams.get('CatName');
    // this.CategoryImage = this.navParams.get('categoryImage');
    this.CategoryID = catId;

    this.GetAllProduct();
  }

  presentModal(param) {
    const modal = this.modalCtrl.create(FurnitureProductDescriptionPage, { ProductInfo: param, CategoryName: this.CategoryID });
    modal.present();
  }

  GetAllProduct() {
    this.database.object('FurnitureDB/Product').valueChanges().subscribe(data => {
      let SubArr = Object.keys(data);
      this.TempProductArrayLeft = [];
      for (var loop = 0; loop < SubArr.length; loop++) {
        if (this.CategoryID == data[SubArr[loop]].Category) {
          const object2 = Object.assign({ ID: SubArr[loop] }, data[SubArr[loop]]);
          // if (loop % 2 == 0) {
          this.TempProductArrayLeft.push(object2);
          // }
          // else {
          //   this.TempProductArrayRight.push(object2)
          // }
        }
      }
    })
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad FurnitureSidemenuCategoryPage');
  }

}
