import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { GeneralProvider } from "../../providers/general/general";
import { FurnitureBookorderPage } from "../furniture-bookorder/furniture-bookorder";

/**
 * Generated class for the FurnitureAddtocartPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */


@Component({
  selector: 'page-furniture-addtocart',
  templateUrl: 'furniture-addtocart.html',
})
export class FurnitureAddtocartPage {

  public Productarray = [];
  public AddtoCart = [];
  public PrintAddtoCart = [];
  TotalAmount = 0;

  constructor(public navCtrl: NavController, public navParams: NavParams, private database: AngularFireDatabase, public ObjGeneral: GeneralProvider) {
    this.GetAllProduct();
    this.GetAllAddtoCart();
    setTimeout(() => {
      this.ShowAddtoCart();
    }, 1000);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad FurnitureAddtocartPage');
  }

  GetAllProduct() {
    this.database.object('FurnitureDB/Product').valueChanges().subscribe(data => {
      let SubArr = Object.keys(data);
      this.Productarray = [];
      for (var loop = 0; loop < SubArr.length; loop++) {
        const object2 = Object.assign({ ID: SubArr[loop] }, data[SubArr[loop]]);
        this.Productarray.push(object2);
      }
    })
  }

  GetAllAddtoCart() {
    this.database.object('FurnitureDB/AddtoCart/' + this.ObjGeneral.DeviceID).valueChanges().subscribe(data => {
      let SubArr = Object.keys(data);
      this.AddtoCart = [];
      for (var loop = 0; loop < SubArr.length; loop++) {
        const object2 = Object.assign({ ID: SubArr[loop] }, data[SubArr[loop]]);
        this.AddtoCart.push(object2);
      }
    })
  }

  PlusFunction(param) {
    var Quantity = param.BucketQuantity;
    Quantity++;
    this.database.list("FurnitureDB/AddtoCart/" + this.ObjGeneral.DeviceID + "/").update(param.AddtoCartID, {
      Product_Quantity: Quantity
    })
    setTimeout(() => {
      this.ShowAddtoCart();
    }, 100);
  }


  MinusFunction(param) {
    var Quantity = param.BucketQuantity;
    Quantity--;
    if (Quantity == 0) {
      this.database.list("FurnitureDB/AddtoCart/" + this.ObjGeneral.DeviceID + "/").remove(param.AddtoCartID)
    }
    else {
      this.database.list("FurnitureDB/AddtoCart/" + this.ObjGeneral.DeviceID + "/").update(param.AddtoCartID, {
        Product_Quantity: Quantity
      })
    }
    setTimeout(() => {
      this.ShowAddtoCart();
    }, 100);
  }

  BookOrder(){
    this.navCtrl.push(FurnitureBookorderPage, {data : this.PrintAddtoCart , NetAmount : this.TotalAmount});
  }

  ShowAddtoCart() {
    this.PrintAddtoCart = [];
    this.TotalAmount = 0;
    
    for (var loop = 1; loop < this.AddtoCart.length; loop++) {
      for (var Innerloop = 0; Innerloop < this.Productarray.length; Innerloop++) {
        if (this.AddtoCart[loop].ProductID == this.Productarray[Innerloop].ID) {
          console.log("Price " + this.Productarray[Innerloop].Price);
          console.log("Quantity " + this.AddtoCart[loop].Product_Quantity);
          var ProductID = this.Productarray[Innerloop].ID;
          var index = this.PrintAddtoCart.findIndex(x => x.ID == ProductID);
          if (index == -1) {
            const object2 = Object.assign({ BucketQuantity: this.AddtoCart[loop].Product_Quantity }, { AddtoCartID: this.AddtoCart[loop].ID }, this.Productarray[Innerloop]);
            this.PrintAddtoCart.push(object2)
            var test = this.Productarray[Innerloop].Price * this.AddtoCart[loop].Product_Quantity;
            this.TotalAmount = this.TotalAmount + test;
          }
          else {
            this.PrintAddtoCart[index].BucketQuantity = this.PrintAddtoCart[index].BucketQuantity + this.AddtoCart[loop].Product_Quantity;
            var test = this.PrintAddtoCart[index].Price * this.AddtoCart[loop].Product_Quantity;
            this.TotalAmount = this.TotalAmount + test;
            // this.database.list("FurnitureDB/AddtoCart/" + this.ObjGeneral.UserName + "/").update(this.PrintAddtoCart[index].AddtoCartID, {
            //   Product_Quantity: this.PrintAddtoCart[index].BucketQuantity
            // })
            // this.database.list("FurnitureDB/AddtoCart/" + this.ObjGeneral.UserName + "/").remove(this.AddtoCart[loop].ID)
            this.database.list("FurnitureDB/AddtoCart/" + this.ObjGeneral.DeviceID + "/").update(this.PrintAddtoCart[index].AddtoCartID, {
              Product_Quantity: this.PrintAddtoCart[index].BucketQuantity
            })
            this.database.list("FurnitureDB/AddtoCart/" + this.ObjGeneral.DeviceID + "/").remove(this.AddtoCart[loop].ID)
          }

        }
      }
    }
  }

}
