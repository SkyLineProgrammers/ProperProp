import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { GeneralProvider } from '../../providers/general/general';
import { FurnitureCatViewPage } from "../furniture-cat-view/furniture-cat-view";
import { FurnitureAddtocartPage } from "../furniture-addtocart/furniture-addtocart";
import { Device } from '@ionic-native/device';
/**
 * Generated class for the FurnitureProductDescriptionPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */


@Component({
  selector: 'page-furniture-product-description',
  templateUrl: 'furniture-product-description.html',
})
export class FurnitureProductDescriptionPage {
  ProductArrayLeft: any[];
  catName: any;

  public ProductName = "";
  public ProductDetail = "";
  public counter = 1;
  public ProductKey = "";
  public ProductInfo = [];
  public BuutonName = "ADD TO CART";
  public Image1 = "";
  public Image2 = "";
  public Image3 = "";
  ProductPrice = 0;
  // DeviceID = "0";
  constructor(public navCtrl: NavController, public navParams: NavParams, public viewCtrl: ViewController, private database: AngularFireDatabase, private ObjGeneral: GeneralProvider, private device: Device) {

    // this.DeviceID = this.device.uuid
    // alert("Device ID " + this.DeviceID);
    // this.getAddToCart();
    this.ProductInfo = this.navParams.get('ProductInfo');
    this.ProductName = this.ProductInfo['ProductName'];
    this.ProductDetail = this.ProductInfo['Description'];
    this.Image1 = this.ProductInfo['Image2'];
    this.Image2 = this.ProductInfo['Image3'];
    this.Image3 = this.ProductInfo['Image4'];
    this.ProductKey = this.ProductInfo['ID'];
    this.ProductPrice = this.ProductInfo["Price"]
    this.catName = this.navParams.get('CategoryName');
    this.GetAllProduct();

  }

  GotoOrder() {
    this.navCtrl.push(FurnitureAddtocartPage);
  }

  GetAllProduct() {
    this.database.object('FurnitureDB/Product').valueChanges().subscribe(data => {
      let SubArr = Object.keys(data);
      this.ProductArrayLeft = [];
      for (var loop = 0; loop < SubArr.length; loop++) {
        if (this.catName == data[SubArr[loop]].Category) {
          const object2 = Object.assign({ ID: SubArr[loop] }, data[SubArr[loop]]);
          this.ProductArrayLeft.push(object2);
        }
      }
    })
  }

  AddToCart() {
    if (this.BuutonName == "ADD TO CART") {
      this.database.list("FurnitureDB/AddtoCart/" + this.ObjGeneral.DeviceID).push({
        DeviceID: this.ObjGeneral.DeviceID,
        ProductID: this.ProductKey,
        Product_Quantity: this.counter
      });
      this.BuutonName = "CONTINUE SHOPPING"
    }
    else {
      this.navCtrl.push(FurnitureCatViewPage);
    }
  }

  minus() {
    if (this.counter > 0) {
      this.counter--;
    }
  }

  plus() {
    if (this.counter < 99) {
      this.counter++;
    }
  }

  dismiss() {
    this.viewCtrl.dismiss();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad FurnitureProductDescriptionPage');
  }

}
